<?php
/**
*
* User Statistics extension for the phpBB Forum Software package.
* Russian translation by HD321kbps
*
* @copyright (c) 2024 HarveyWNvm LLC. <harveynomvervevo@gmail.com>
* @license GNU General Public License, version 3 (GPL-3.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'US_USER_IP'		=> 'Вашето IP',
	'US_USER_REGDATE'	=> 'Вашата дата на регистрация',
	'US_USER_ID'		=> 'Вашият ID',
	'US_USER_POSTS'		=> 'вашите съобщения',
	'US_USER_TOPICS'	=> 'Вашите публикации',
	'US_USER_RTITLE'	=> 'Вашето заглавие',
	'US_NO_RANK'		=> 'Без ранг',
));
